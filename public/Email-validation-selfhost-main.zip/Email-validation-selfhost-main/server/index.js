import express from 'express';
import cors from 'cors';
import net from 'net';
import dns from 'dns';
import { promisify } from 'util';

const resolveMx = promisify(dns.resolveMx);
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3001;
let isPort25Open = false;

// Auto-detect Port 25 on startup
async function checkPort25() {
    return new Promise((resolve) => {
        const socket = net.createConnection(25, 'smtp.gmail.com');
        socket.setTimeout(5000);
        socket.on('connect', () => {
            isPort25Open = true;
            socket.destroy();
            resolve(true);
        });
        socket.on('error', () => {
            isPort25Open = false;
            resolve(false);
        });
        socket.on('timeout', () => {
            isPort25Open = false;
            socket.destroy();
            resolve(false);
        });
    });
}

checkPort25();

app.get('/api/status', (req, res) => {
    res.json({
        active: true,
        port25: isPort25Open,
        message: isPort25Open ? "System ready for handshakes." : "Port 25 is blocked by your provider."
    });
});

app.post('/api/verify-smtp', async (req, res) => {
    const { email } = req.body;
    if (!email || !email.includes('@')) {
        return res.status(400).json({ error: "Invalid email" });
    }

    const domain = email.split('@')[1];

    try {
        const mxRecords = await resolveMx(domain);
        if (!mxRecords || mxRecords.length === 0) {
            return res.json({ success: false, reason: "No MX records found" });
        }

        // Sort by priority
        mxRecords.sort((a, b) => a.priority - b.priority);
        const host = mxRecords[0].exchange;

        const result = await performHandshake(host, email);
        res.json(result);
    } catch (error) {
        res.json({ success: false, reason: "DNS resolution failed or connection error", details: error.message });
    }
});

function performHandshake(host, targetEmail) {
    return new Promise((resolve) => {
        const socket = net.createConnection(25, host);
        let step = 0;
        let result = { success: false, reason: "Unknown error" };

        socket.setTimeout(10000);

        socket.on('data', (data) => {
            const response = data.toString();
            const code = parseInt(response.substring(0, 3));

            if (step === 0 && code === 220) {
                socket.write(`HELO cleanmails.online\r\n`);
                step++;
            } else if (step === 1 && code === 250) {
                socket.write(`MAIL FROM:<verify@cleanmails.online>\r\n`);
                step++;
            } else if (step === 2 && code === 250) {
                socket.write(`RCPT TO:<${targetEmail}>\r\n`);
                step++;
            } else if (step === 3) {
                if (code === 250) {
                    result = { success: true, reason: "Inbox exists (Delivered)" };
                } else if (code === 550) {
                    result = { success: false, reason: "Inbox does not exist (Bounced)" };
                } else {
                    result = { success: false, reason: `Server responded with ${code}: ${response.split('\n')[0]}` };
                }
                socket.write('QUIT\r\n');
                socket.end();
            }
        });

        socket.on('error', (err) => {
            resolve({ success: false, reason: `SMTP Error: ${err.message}` });
        });

        socket.on('timeout', () => {
            socket.destroy();
            resolve({ success: false, reason: "Connection timed out" });
        });

        socket.on('close', () => {
            resolve(result);
        });
    });
}

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Handshake Bridge running on port ${PORT}`);
});
